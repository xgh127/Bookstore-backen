package com.bookstore.backen.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "book")
public class Book
{
    @Id
    @Column(name = "id", nullable = false)
    private int id;

    private String title;
    private String author;
    private String price;
    private String type;
    private String description;
    private String image;//图片的url

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Book() {
    }

    public Book(int id, String title, String author, String price, String type, String description, String image) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.price = price;
        this.type = type;
        this.description = description;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return String.format(
                "Book[id=%d, title='%s', author='%s', price='%s', type='%s', description='%s']",
                id, title, author, price, type, description);
    }
}

