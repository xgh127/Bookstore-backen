package com.bookstore.backen.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * User 实体类
 * */
@Table(name = "user_auth")
@Entity
public class User {
    @Id
    @Column(name = "user_id", nullable = false)
    private Integer user_id;      //用户编号
    private String username;     //用户名
    private String password;     //用户密码
    private Integer user_type;

    public User(Integer user_id, String username, String password, Integer user_type) {
        this.user_id = user_id;
        this.username = username;
        this.password = password;
        this.user_type = user_type;
    }

    public String getUsername() {
        return username;
    }

    public Integer getUser_type() {
        return user_type;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public Integer getUser_type(Integer user_type) {
        return this.user_type;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }


    public void setPassword(String password) {
        this.password = password;
    }

    public void setUser_type(Integer user_type) {
        this.user_type = user_type;
    }

    public User() {
    }
}


