package com.bookstore.backen.DaoImpl;

import com.bookstore.backen.Dao.BookDao;
import com.bookstore.backen.entity.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class BookDaoImpl implements BookDao
{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public List<Book> getBooks()
    {
        List<Book> books = new ArrayList<>();
        List<Map<String,Object>> rows = jdbcTemplate.queryForList("SELECT * from book");
        for(Map row:rows)
        {
            Book obj = new Book();
            obj.setId((Integer)row.get("id"));
            obj.setTitle((String)row.get("name"));
            obj.setAuthor((String)row.get("author") );
            obj.setPrice(String.valueOf( row.get("price")));
            obj.setType((String.valueOf(row.get("type"))));
            obj.setDescription((String)row.get("description"));
            obj.setImage((String)row.get("image") );
            books.add(obj);
        }
        return books;
    }
    @Override
    public List<Book> findOne(Integer id)
    {
        String sql = "select * from book where id = ?";
        List<Book> books = new ArrayList<>();
        List<Map<String,Object>> rows =jdbcTemplate.queryForList(sql+id);
        for(Map row:rows)
        {
            Book obj = new Book();
            obj.setId((Integer)row.get("id"));
            obj.setTitle((String)row.get("name"));
            obj.setAuthor((String)row.get("author") );
            obj.setPrice(String.valueOf( row.get("price")));
            obj.setType((String.valueOf(row.get("type"))));
            obj.setDescription((String)row.get("description"));
            obj.setImage((String)row.get("image") );
            books.add(obj);
        }
        return books;
    }
}
