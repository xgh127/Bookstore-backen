package com.bookstore.backen.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Types;

public class CartDaoImpl {
    @Autowired
    JdbcTemplate jdbcTemplate;
//    public void insert(Integer id,Double price)
//    {
//        String sql = "insert into cart values(?,?)";
//        jdbcTemplate.update(sql,new Object[]{id,price});
//    }
}
