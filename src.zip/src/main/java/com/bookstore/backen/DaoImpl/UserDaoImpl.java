package com.bookstore.backen.DaoImpl;


import com.bookstore.backen.Dao.UserDao;
import com.bookstore.backen.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Repository
public class UserDaoImpl implements UserDao
{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public User checkUser(String username, String password)
    {
        /*去表里遍历所有是数据*/
        List<User> users = new ArrayList<>();
        List<Map<String,Object>> rows = jdbcTemplate.queryForList("SELECT * from user_auth");
        for(Map row:rows)
        {
            User obj = new User();
            obj.setUser_id(((Integer)row.get("user_id")));
            obj.setUsername(((String)row.get("username")));
            obj.setPassword((String)row.get("password"));
            obj.getUser_type((Integer)row.get("user_type"));
            users.add(obj);
        }
        /*检查是否有匹配的用户*/
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }
}

