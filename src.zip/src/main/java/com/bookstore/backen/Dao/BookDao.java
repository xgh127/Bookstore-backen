package com.bookstore.backen.Dao;

import com.bookstore.backen.entity.Book;
import java.util.List;


public interface BookDao
{
    List<Book> getBooks();
    List<Book> findOne(Integer id);
}
