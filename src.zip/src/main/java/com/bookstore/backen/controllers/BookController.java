package com.bookstore.backen.controllers;

import com.bookstore.backen.Dao.BookDao;
import com.bookstore.backen.entity.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.Types;
import java.util.List;

@RestController
public class BookController {
    @Autowired
    private BookDao bookDao;
    @Autowired
    JdbcTemplate jdbcTemplate;

    @RequestMapping(value = "/getBooks")
    public List<Book> getBooks() {
        System.out.println("enter in");
        List<Book> books = bookDao.getBooks();
        System.out.println(books.get(0).getPrice());
        return books;
    }

    @RequestMapping(value = "/findOne", method = RequestMethod.GET)
    public Book getOne(@RequestParam(value = "id") Integer id) {
        System.out.println(id);
        List<Book> books = bookDao.findOne(id);
        if (books != null) {
            return books.get(0);
        } else {
            return null;
        }
    }
}
