package com.bookstore.backen.constant;

import java.sql.Timestamp;

// 所有的通用字段在这里统一写明
public class constant {

    // 用户相关 和数据库的字段名字统一 这里对应users表格
    public static final String USERID = "userId";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String PRIVILEGE = "privilege";
    public static final String EMAIL = "email";
    public static final String FORBIDLOGIN = "forbidlogin";
    public static final String LOGIN_TIME = "login_time";

    public static final int INVALID_ITEM = -1;


    public static final String REFRESHED_BUY_NUM = "refreshedbuynum";
    public static final String ORDER_ITEMID = "itemID";

    // 用户操作的相关
    public static final String SET_OBJ_USERNAME = "setUsername";


    public static final String SIGNATURE = "Signature";


    public static final String ISBN = "ISBN";
    public static final String AUTHOR = "author";
    public static final String PRICE = "price";

}
