package com.example.my_baken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBakenApplicationTests {

    @Test
    void contextLoads() {
    }

}
